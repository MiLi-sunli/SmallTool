package com.example.demo.utils;

import com.example.demo.DTO.UploadFileInfoDTO;
import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

@Slf4j
public class HttpRequestUtils {

    /**
     * upload file request
     * @param uploadFileInfoDTO
     * @return
     * @throws Exception
     */
    public static String uploadRequest(UploadFileInfoDTO uploadFileInfoDTO) throws Exception {
        URL url = new URL(uploadFileInfoDTO.getUrl());
        HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
        httpConn.setConnectTimeout(3000);   // 设置发起连接的等待时间，3s
        httpConn.setReadTimeout(30000);     // 设置数据读取超时的时间，30s
        httpConn.setUseCaches(false);       // 设置不使用缓存
        httpConn.setDoOutput(true);
        httpConn.setRequestMethod("POST");

        httpConn.setRequestProperty("Connection", "Keep-Alive");
        httpConn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 6.1; zh-CN; rv:1.9.2.6)");
        httpConn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + uploadFileInfoDTO.getBoundary());
        OutputStream os = httpConn.getOutputStream();
        BufferedOutputStream bos = new BufferedOutputStream(os);

        String content = "--" + uploadFileInfoDTO.getBoundary() + "\r\n";
        content       += "Content-Disposition: form-data; name=\"file\"" + "\r\n\r\n";
        content       += "我是post数据的值";
        content       += "\r\n--" + uploadFileInfoDTO.getBoundary() + "\r\n";
        content       += "Content-Disposition: form-data; name=\"file\"; filename=\"" + uploadFileInfoDTO.getFileName() + "\"\r\n";
        content       += "Content-Type: image/jpeg\r\n\r\n";
        bos.write(content.getBytes());

        // 开始写出文件的二进制数据
        FileInputStream fin = new FileInputStream(new File(uploadFileInfoDTO.getFileFullPath()));
        BufferedInputStream bfi = new BufferedInputStream(fin);
        byte[] buffer = new byte[4096];
        int bytes = bfi.read(buffer, 0, buffer.length);

        while (bytes != -1) {
            bos.write(buffer, 0, bytes);
            bytes = bfi.read(buffer, 0, buffer.length);
        }

        bfi.close();
        fin.close();
        bos.write(("\r\n--" + uploadFileInfoDTO.getBoundary()).getBytes());
        bos.flush();
        bos.close();
        os.close();

        // 读取返回数据
        StringBuffer strBuf = new StringBuffer();
        BufferedReader reader = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
        String line = null;
        while ((line = reader.readLine()) != null) {
            strBuf.append(line).append("\n");
        }

        String res = strBuf.toString();
        System.out.println("上传接口返回:" + res);
        reader.close();
        httpConn.disconnect();

        return res;
    }
}

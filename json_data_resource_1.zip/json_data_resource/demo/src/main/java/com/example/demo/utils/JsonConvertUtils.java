package com.example.demo.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.DTO.JsonForFrontDTO;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonConvertUtils {

    /**
     *
     */
    public static Object convertFrontDtoToJsonObject(JSONObject frontObject) {
        // 第一层
        Map<String, Object> result = new HashMap<>();

        JsonForFrontDTO jsonForFrontDTO = JSON.toJavaObject(frontObject, JsonForFrontDTO.class);

        List<JsonForFrontDTO> objectList = jsonForFrontDTO.getChild();

        for (JsonForFrontDTO frontDTO : objectList) {
            result.put(frontDTO.getName(), convertFrontDtoToJsonObject(frontDTO));
        }

        return result;
    }

    /**
     * convert data by iteration
     */
    private static Object convertFrontDtoToJsonObject(JsonForFrontDTO jsonForFrontDTO) {
        Object object = null;

        if ("JSONObject".equals(jsonForFrontDTO.getDataType())) {
            Map<String, Object> result = new HashMap<>();

            for (JsonForFrontDTO frontDTO : jsonForFrontDTO.getChild()) {
                result.put(frontDTO.getName(), convertFrontDtoToJsonObject(frontDTO));
            }

            object = result;
        } else if ("JSONArray".equals(jsonForFrontDTO.getDataType())) {
            List<Object> list = new ArrayList<>();

            for (JsonForFrontDTO frontDTO : jsonForFrontDTO.getChild()) {
                list.add(convertFrontDtoToJsonObject(frontDTO));
            }

            object = list;
        } else if (StringUtils.isEmpty(jsonForFrontDTO.getDataType())) {
            object = jsonForFrontDTO.getValue();
        }

        return object;
    }

    /**
     * convert normal JSON to target JSON
     */
    public static JsonForFrontDTO convertJsonObjectToFrontDTO(JSONObject object2) {
        // first layer data structure
        JsonForFrontDTO resultDto = new JsonForFrontDTO();

        resultDto.setId("1");
        resultDto.setLevel(1);
        resultDto.setName("Root");
        resultDto.setParentId("0");
        resultDto.setParentName(null);
        resultDto.setDataType(getDateType(object2));
        resultDto.setValue(null);

        int dataNum = 1;

        int level = 1;

        List<JsonForFrontDTO> list = convertToFrontDTO(resultDto, object2, dataNum, level + 1);
        resultDto.setChild(list);
        return resultDto;
    }

    /**
     * get sub list data by iteration
     */
    private static List<JsonForFrontDTO> convertToFrontDTO(JsonForFrontDTO fatherDto, Object object, int dataNum, int level) {
        if (null == object) {
            return new ArrayList<>();
        }

        List<JsonForFrontDTO> list = new ArrayList<>();

        if (object instanceof JSONObject) {
            JSONObject jsonObject = (JSONObject) object;

            // 用以拼接下层的id值
            int num = 1;

            for (Map.Entry entry : jsonObject.entrySet()) {
                JsonForFrontDTO nodeDto = generateNodeDtoInfo(fatherDto, entry, num, level);

                // 根据value值判断下一层是否为叶子节点，如果为叶子节点，则直接进行赋值
                if (entry.getValue() instanceof java.lang.String) {
                    nodeDto.setValue(String.valueOf(entry.getValue()));
                } else {
                    nodeDto.setChild(convertToFrontDTO(nodeDto, entry.getValue(), num, level + 1));
                    nodeDto.setDataType(getDateType(entry.getValue()));
                }

                list.add(nodeDto);
                num++;
            }
        } else if (object instanceof JSONArray) {
            JSONArray jsonArray = (JSONArray) object;

            for (int index = 0; index < jsonArray.size(); index++) {
                JsonForFrontDTO arrayDto = generateNodeDtoInfo(fatherDto, String.valueOf(index), index + 1, level);

                // 根据value值判断下一层是否为叶子节点，如果为叶子节点，则直接进行赋值
                if (jsonArray.get(index) instanceof java.lang.String) {
                    arrayDto.setValue(String.valueOf(jsonArray.get(index)));
                } else {
                    arrayDto.setChild(convertToFrontDTO(arrayDto, jsonArray.get(index), index + 1, level + 1));
                    arrayDto.setDataType(getDateType(jsonArray.get(index)));
                }

                list.add(arrayDto);
            }
        } else {
            System.out.println("Object type mismatched : " + String.valueOf(object));
        }

        return list;
    }

    /**
     * assembly generates JSON object
     */
    private static JsonForFrontDTO generateNodeDtoInfo(JsonForFrontDTO fatherDto, Object object, int num, int level) {
        JsonForFrontDTO nodeDto = new JsonForFrontDTO();

        nodeDto.setId(fatherDto.getId() + "-" + num);
        nodeDto.setLevel(level);
        nodeDto.setParentId(fatherDto.getId());
        nodeDto.setParentName(fatherDto.getName());

        if (object instanceof java.lang.String) {
            nodeDto.setName(String.valueOf(object));
        } else if (object instanceof Map.Entry) {
            nodeDto.setName(String.valueOf(((Map.Entry) object).getKey()));
        } else {
            System.out.println("Object type mismatched : " + String.valueOf(object));
        }

        return nodeDto;
    }

    /**
     * get this object data type
     */
    private static String getDateType(Object object) {
        String type = null;

        if (object instanceof JSONObject) {
            type = "JSONObject";
        } else if (object instanceof JSONArray) {
            type = "JSONArray";
        }

        return type;
    }
}

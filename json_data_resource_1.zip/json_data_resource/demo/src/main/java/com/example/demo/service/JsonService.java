package com.example.demo.service;

import com.example.demo.DTO.JsonForFrontDTO;
import com.example.demo.DTO.KeyValueDTO;

import java.util.List;
import java.util.Map;

public interface JsonService {
    List<Map> test();

    JsonForFrontDTO getTestCaseJsonFromDataBase(Integer caseId) throws Exception ;

    void insertJsonDataToDB(Integer caseId, JsonForFrontDTO dto);

    Map<String, String> getAllLeafNodeInfo(Integer caseId);

    void updateJsonData(Integer caseId, List<KeyValueDTO> list);
}

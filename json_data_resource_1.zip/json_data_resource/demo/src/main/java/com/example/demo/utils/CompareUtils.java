package com.example.demo.utils;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.*;

public class CompareUtils {

    /**
     * new Object contains old Object
     * @param oldObj
     * @param newObj
     * @return
     */
    public static boolean containsObject(Object oldObj, Object newObj) {
        Map<String, List<Object>> resultMap = compareFields(oldObj, newObj);

        if (resultMap.isEmpty()) {
            return true;
        }

        return false;
    }

    @SuppressWarnings("rawtypes")
    public static Map<String, List<Object>> compareFields(Object oldObj, Object newObj) {
        try{
            Map<String, List<Object>> map = new HashMap<String, List<Object>>();

                Class clazz = oldObj.getClass();
                // 获取object的属性描述
                PropertyDescriptor[] pds = Introspector.getBeanInfo(clazz, Object.class).getPropertyDescriptors();

                //
                for (PropertyDescriptor pd : pds) {
                    String name = pd.getName();   // 属性名

                    Method readMethod = pd.getReadMethod();// get方法
                    // 在obj1上调用get方法等同于获得obj1的属性值
                    Object o1 = readMethod.invoke(oldObj);
                    // 在obj2上调用get方法等同于获得obj2的属性值
                    Object o2 = readMethod.invoke(newObj);

                    if(o1 instanceof Timestamp){
                        o1 = new Date(((Timestamp) o1).getTime());
                    }

                    if(o2 instanceof Timestamp){
                        o2 = new Date(((Timestamp) o2).getTime());
                    }

                    if (o1 == null && o2 == null) {
                        continue;
                    } else if (o1 == null && o2 != null) {
                        List<Object> list = new ArrayList<Object>();
                        list.add(o1);
                        list.add(o2);
                        map.put(name, list);
                        continue;
                    }

                    if (!o1.equals(o2)) { // 比较这两个值是否相等,不等就可以放入map了
                        List<Object> list = new ArrayList<Object>();
                        list.add(o1);
                        list.add(o2);
                        map.put(name, list);
                    }
                }
            return map;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

package com.example.demo.utils;

import com.alibaba.fastjson.JSON;
import com.example.demo.DTO.UploadFileInfoDTO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {

        Map<String, Object> map1 = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();

        List<String> list1 = new ArrayList<>();
        List<String> list2 = new ArrayList<>();

        for (int index = 0; index < 10; index++) {
            list1.add(String.valueOf(index));
            list2.add(String.valueOf(index));
        }

        UploadFileInfoDTO dto = new UploadFileInfoDTO();
        dto.setUrl("Https://test/test");

        //list2.add("14");

        map1.put("12", list1);
        map1.put("13", "4567");
        map1.put("14", "45678");
        map1.put("15", dto);

        map2.put("13", "4567");
        map2.put("12", list2);
        map2.put("15", dto);

        System.out.println(JsonUtils.same(JSON.toJSONString(map1), JSON.toJSONString(map2)));
    }
}

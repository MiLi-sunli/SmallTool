package com.example.demo.dao;

import com.example.demo.DTO.JsonForFrontDTO;
import com.example.demo.DTO.KeyValueDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface JsonDao {
    int test();

    List<JsonForFrontDTO> getTestCaseJsonFromDataBase(Integer caseId, String parentId);

    void insertJsonDataToDB(Integer caseId, List<JsonForFrontDTO> list);

    List<KeyValueDTO> getAllLeafNodeInfo(Integer caseId);

    void batchUpdateJsonData(Integer caseId, List<KeyValueDTO> list);

    List<Map> getAllLeafNode(Integer caseId);
}

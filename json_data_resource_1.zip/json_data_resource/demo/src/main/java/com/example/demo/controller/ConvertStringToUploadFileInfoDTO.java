package com.example.demo.controller;

import com.example.demo.DTO.UploadFileInfoDTO;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class ConvertStringToUploadFileInfoDTO implements Converter<String, UploadFileInfoDTO> {
    @Override
    public UploadFileInfoDTO convert(String source) {
        UploadFileInfoDTO dto = new UploadFileInfoDTO();

        dto.setFileName(source);
        dto.setBoundary(source);
        dto.setUrl(source);

        return dto;
    }
}

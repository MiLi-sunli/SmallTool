package com.example.demo.utils;

public class Main2 {
    public static void main(String[] args) {
        System.out.println(ExcelUtils.covertLetterToNum("ZQ"));
        System.out.println(ExcelUtils.CovertNumToLetter(774));
    }
}

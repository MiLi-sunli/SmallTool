package com.example.demo.utils;

import com.example.demo.DTO.UploadFileInfoDTO;

public class CompareMain {
    public static void main(String[] args) {
        UploadFileInfoDTO oldDto = new UploadFileInfoDTO();
        oldDto.setUrl("http://123/tet");


        UploadFileInfoDTO newDto = new UploadFileInfoDTO();
        newDto.setUrl("http://123/tet");
        //newDto.setFileName("test_newDto");

        System.out.println(CompareUtils.containsObject(oldDto, newDto));
    }
}

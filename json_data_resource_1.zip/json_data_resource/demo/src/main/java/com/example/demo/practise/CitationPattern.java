package com.example.demo.practise;

/**
 * 原型模型
 * 多个对象相似，使用原型clone可以节省创建对象个数
 */
public class CitationPattern {
    public static void main(String[] args) throws CloneNotSupportedException {
        citation obj1 = new citation("张三", "同学", "韶关学院");
        obj1.display();
        citation obj2 = (citation) obj1.clone();
        obj2.setName("李四");
        obj2.display();
    }

    // 奖状类
    static class citation implements Cloneable {
        String name;
        String info;
        String college;

        citation(String name, String info, String college) {
            this.name = name;
            this.info = info;
            this.college = college;
            System.out.println("奖状创建成功!");
        }

        void setName(String name) {
            this.name = name;
        }

        String getName() {
            return this.name;
        }

        void display() {
            System.out.println(name + info + college);
        }

        public Object clone() throws CloneNotSupportedException {
            System.out.println("奖状拷贝成功");
            return (citation) super.clone();
        }
    }
}

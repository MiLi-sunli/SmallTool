package com.example.demo.DTO;

import lombok.Data;

@Data
public class KeyValueDTO {
    private String id;

    private String value;
}

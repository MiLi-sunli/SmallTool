package com.example.demo.utils;

import org.apache.commons.lang3.StringUtils;

public class ExcelUtils {

    /**
     * calc column num by column name
     */
    public static int covertLetterToNum(String colName) {
        char[] chars = colName.toCharArray();

        int value = 0;
        int pos = 1;

        for (int i = chars.length - 1; i >= 0; i--) {
            int tmp = chars[i] - 64;
            value += (tmp * pos);
            pos *= 26;
        }

        return value;
    }

    public static String CovertNumToLetter(int num) {
        if (num <= 0) {
            throw new RuntimeException("参数必须大于0");
        }

        String str = StringUtils.EMPTY;

        while (num > 0) {
            int res = num % 26;
            if (res == 0) {
                res = 26;
            }

            str = (char) (res + 64) + str;
            num = (num - res) / 26;
        }


        return str;
    }
}

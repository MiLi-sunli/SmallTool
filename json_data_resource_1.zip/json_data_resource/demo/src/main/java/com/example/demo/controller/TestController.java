package com.example.demo.controller;

import com.alibaba.fastjson.JSON;
import com.example.demo.DTO.UploadFileInfoDTO;
import com.example.demo.config.WebSocketServer;
import com.example.demo.utils.HttpRequestUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/test")
public class TestController {

    @Value("${upload.filePath}")
    private String filePath;

    @Value("${upload.boundary}")
    private String boundary;

    @GetMapping("/testMethod")
    public String testMethod() {
        return filePath;
    }

    @PostMapping("/upload")
    public String upload() throws Exception {
        UploadFileInfoDTO uploadFileInfoDTO = new UploadFileInfoDTO();
        uploadFileInfoDTO.setUrl("http://localhost:8080/test/uploadFile");
        uploadFileInfoDTO.setFileName("Employee_handbook.pdf");
        uploadFileInfoDTO.setFileFullPath("C:\\Users\\86138\\Desktop\\Employee_handbook.pdf");
        uploadFileInfoDTO.setBoundary(boundary);

        return HttpRequestUtils.uploadRequest(uploadFileInfoDTO);
    }

    @PostMapping("/uploadFile")
    public String uploadFile(@RequestParam(value = "file", required = false) MultipartFile file) {

        File targetFile = new File(filePath);
        if (!targetFile.exists()) {
            targetFile.mkdirs();
        }
        try (FileOutputStream out = new FileOutputStream(filePath + "/" + file.getOriginalFilename());){
            out.write(file.getBytes());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("文件上传失败!");
            return "uploading failure";
        }

        log.info("文件上传成功!");

        return "Success";
    }

    // 推送数据接口
    @ResponseBody
    @PostMapping("/socket/push/{cid}")
    public String pushToWeb(@PathVariable String cid, String message) {

        Map<String, String> map = new HashMap<>();
        map.put("key", message);

        WebSocketServer.sendInfo(JSON.toJSONString(map), cid);
        return cid;
    }


    @ResponseBody
    @GetMapping("/convertParam")
    public String convertParam(@RequestParam TableType tableType) {
        return tableType.name();
    }

    public enum TableType {
        TABLE_A, TABLE_B, TABLE_C;
    }
}

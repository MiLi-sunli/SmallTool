package com.example.demo.service.impl;

import com.example.demo.DTO.JsonForFrontDTO;
import com.example.demo.DTO.KeyValueDTO;
import com.example.demo.dao.JsonDao;
import com.example.demo.service.JsonService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class JsonServiceImpl implements JsonService {

    @Resource
    private JsonDao jsonDao;

    @Override
    public List<Map> test() {

        List<Map> resultList = jsonDao.getAllLeafNode(Integer.parseInt("1"));

        for (Map entry : resultList) {
            System.out.println("Lee test key:" + entry.get("id"));
            System.out.println("Lee test value:" + entry.get("value"));
        }

        return resultList;
    }

    @Override
    public JsonForFrontDTO getTestCaseJsonFromDataBase(Integer caseId) throws Exception {
        List<JsonForFrontDTO> rootList = jsonDao.getTestCaseJsonFromDataBase(caseId, "0");

        if (CollectionUtils.isEmpty(rootList)) {
            throw new Exception("不存在此用例信息");
        }

        JsonForFrontDTO rootDto = rootList.get(0);
        rootDto.setChild(getChildByFather(caseId, rootDto));

        return rootDto;
    }

    @Override
    public void insertJsonDataToDB(Integer caseId, JsonForFrontDTO dto) {
        List<JsonForFrontDTO> list = getAllNodeJsonDto(dto);

        if (!CollectionUtils.isEmpty(list)) {
            jsonDao.insertJsonDataToDB(caseId, list);
        }
    }

    @Override
    public Map<String, String> getAllLeafNodeInfo(Integer caseId) {

        Map<String, String> map = new HashMap<>();

        List<KeyValueDTO> list = jsonDao.getAllLeafNodeInfo(caseId);

        for (KeyValueDTO dto : list) {
            map.put(dto.getId(), dto.getValue());
        }

        return map;
    }

    @Override
    public void updateJsonData(Integer caseId, List<KeyValueDTO> list) {
        if (!CollectionUtils.isEmpty(list)) {
            jsonDao.batchUpdateJsonData(caseId, list);
        }
    }

    private List<JsonForFrontDTO> getAllNodeJsonDto(JsonForFrontDTO dto) {

        List<JsonForFrontDTO> result = new ArrayList<>();

        JsonForFrontDTO oneLevelDto = copyJsonForFrontDtoWithOutChild(dto);
        result.add(oneLevelDto);

        addAllJsonDto(result, dto);

        return result;
    }

    private JsonForFrontDTO copyJsonForFrontDtoWithOutChild(JsonForFrontDTO dto) {
        JsonForFrontDTO result = new JsonForFrontDTO();

        result.setId(dto.getId());
        result.setLevel(dto.getLevel());
        result.setName(dto.getName());
        result.setParentId(dto.getParentId());
        result.setParentName(dto.getParentName());
        result.setValue(dto.getValue());
        result.setDataType(dto.getDataType());

        return result;
    }

    private void addAllJsonDto(List<JsonForFrontDTO> result, JsonForFrontDTO dto) {
        if (null == dto || null == dto.getChild()) {
            return;
        }

        for (JsonForFrontDTO jsonDto : dto.getChild()) {
            JsonForFrontDTO levelDto = copyJsonForFrontDtoWithOutChild(jsonDto);
            result.add(levelDto);

            addAllJsonDto(result, jsonDto);
        }
    }

    private List<JsonForFrontDTO> getChildByFather(Integer caseId, JsonForFrontDTO fatherDto) {
        if (StringUtils.isEmpty(fatherDto.getDataType())) {
            return null;
        }

        List<JsonForFrontDTO> jsonObjectList = jsonDao.getTestCaseJsonFromDataBase(caseId, fatherDto.getId());

        for (JsonForFrontDTO frontDTO : jsonObjectList) {
            frontDTO.setChild(getChildByFather(caseId, frontDTO));
        }

        return CollectionUtils.isEmpty(jsonObjectList) ? new ArrayList<>() : jsonObjectList;
    }
}

package com.example.demo.controller;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class ConvertStringToEnum implements Converter<String, TestController.TableType> {
    @Override
    public TestController.TableType convert(String source) {
        return Arrays.asList(TestController.TableType.values()).stream()
                .filter(tableType -> tableType.ordinal() == Integer.parseInt(source)).findFirst().orElse(TestController.TableType.TABLE_A);
    }
}

package com.example.demo.DTO;

import lombok.Data;

import java.util.List;

@Data
public class ReceiveDataDTO {
    private List<KeyValueDTO> list;
}

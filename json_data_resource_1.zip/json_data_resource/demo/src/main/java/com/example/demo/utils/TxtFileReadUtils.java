package com.example.demo.utils;

import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class TxtFileReadUtils {

    /**
     * read file by file path
     * @param filePath
     * @return
     */
    public static List<String> ReadFile(String filePath) {
        File file = new File(filePath);

        if (file.isFile() && file.exists()) {
            return ReadFile(file);
        }

        return new ArrayList<>();
    }

    /**
     * read file by file
     * @param file
     * @return
     */
    public static List<String> ReadFile(File file) {
        List<String> resultList = new ArrayList<>();

        if (!file.exists()) {
            return resultList;
        }

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String str = null;

            // read the content line by line
            while ((str = br.readLine()) != null) {
                resultList.add(str);
            }

            // close the file reader
            br.close();
        } catch (FileNotFoundException e) {
            log.error("ReadFile has FileNotFoundException : ", e.getMessage());
        } catch (IOException e) {
            log.error("ReadFile has IOException : ", e.getMessage());
        }

        return resultList;
    }
}

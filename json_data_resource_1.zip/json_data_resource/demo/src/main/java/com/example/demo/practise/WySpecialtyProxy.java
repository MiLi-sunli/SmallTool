package com.example.demo.practise;

// 代理设计模式
public class WySpecialtyProxy {
    public static void main(String[] args) {
        SgProxy proxy = new SgProxy();

        proxy.display();
    }

    // 抽象主题：特产
    interface Specialty {
        void display();
    }

    // 真实主题: 陕西特产
    static class WySpecialty implements Specialty {
        @Override
        public void display() {
            System.out.println("陕西特产显示");
        }
    }

    // 代理：韶关代理
    static class SgProxy implements Specialty {

        private WySpecialty realSpecialty = new WySpecialty();

        @Override
        public void display() {
            System.out.println("访问主题前");
            realSpecialty.display();
            System.out.println("访问主题后");
        }
    }
}

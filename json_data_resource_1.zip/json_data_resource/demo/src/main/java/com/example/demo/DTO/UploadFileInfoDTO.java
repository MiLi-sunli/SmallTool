package com.example.demo.DTO;

import lombok.Data;

@Data
public class UploadFileInfoDTO {
    //
    private String url;

    //
    private String fileName;

    //
    private String fileFullPath;

    //
    private String boundary;

    @Override
    public String toString() {
        return "UploadFileInfoDTO{" +
                "url='" + url + '\'' +
                ", fileName='" + fileName + '\'' +
                ", fileFullPath='" + fileFullPath + '\'' +
                ", boundary='" + boundary + '\'' +
                '}';
    }
}

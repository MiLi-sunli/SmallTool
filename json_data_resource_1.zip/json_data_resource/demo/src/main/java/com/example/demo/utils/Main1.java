package com.example.demo.utils;

import java.util.List;

public class Main1 {
    public static void main(String[] args) {
        //String filePath = "C:\\Users\\86138\\Desktop\\新建文本文档.csv";

        String filePath = "C:\\Users\\86138\\Desktop\\123.txt";

        List<String> list = TxtFileReadUtils.ReadFile(filePath);

        for (String str : list) {
            System.out.println(str);
        }
    }
}

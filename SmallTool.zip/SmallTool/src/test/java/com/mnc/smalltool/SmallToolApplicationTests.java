package com.mnc.smalltool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmallToolApplicationTests {

    @Test
    void contextLoads() {
    }

}

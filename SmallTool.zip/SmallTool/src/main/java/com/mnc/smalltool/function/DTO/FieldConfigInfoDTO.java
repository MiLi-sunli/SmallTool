package com.mnc.smalltool.function.DTO;

import java.io.Serializable;

public class FieldConfigInfoDTO implements Serializable {

    private static final long serialVersionUID = 4106567559415906401L;

    // 字段名称
    private String field;

    // 值域
    private String valueRange;

    // 值域的可能个数
    private Integer valueNum;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getValueRange() {
        return valueRange;
    }

    public void setValueRange(String valueRange) {
        this.valueRange = valueRange;
    }

    public Integer getValueNum() {
        return valueNum;
    }

    public void setValueNum(Integer valueNum) {
        this.valueNum = valueNum;
    }

    @Override
    public String toString() {
        return "FieldConfigInfoDTO{" +
                "field='" + field + '\'' +
                ", valueRange='" + valueRange + '\'' +
                ", valueNum=" + valueNum +
                '}';
    }
}

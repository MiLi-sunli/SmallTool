package com.mnc.smalltool.function.impl;

import com.mnc.smalltool.config.Config;
import com.mnc.smalltool.function.DTO.FieldConfigInfoDTO;
import com.mnc.smalltool.function.ToolFunction;
import com.mnc.smalltool.utils.ExcelUtils;
import com.mnc.smalltool.utils.TxtFileReadUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

public class TestCaseFunctionImpl implements ToolFunction {
    @Override
    public String checkFunctionParam(Config config) {
        return null;
    }

    @Override
    public void executeFunction(Config config) {
        // 读取用例字段信息
        List<FieldConfigInfoDTO> testCaseFields = readTestCaseField(config);

        // 根据用例字段配置信息生成用例数据
        List<String> testCaseInfos = generateTestCaseStringInfo(config, testCaseFields);

        // 生成csv格式的用例数据
        generateTestCaseCsvFile(config, testCaseInfos, generateTestCaseHeader(testCaseFields));
    }

    /**
     * 读取用例字段的配置信息
     */
    private List<FieldConfigInfoDTO> readTestCaseField(Config config) {
        String outYmlFilePath = System.getProperty("user.dir") + "\\" + config.getTestCaseConfigFileName();
        Workbook wb = ExcelUtils.getWorkBook(outYmlFilePath);

        List<FieldConfigInfoDTO> fieldConfigInfoDTOList = new ArrayList<>();
        // 获取参数配置页
        Sheet st = wb.getSheet("Sheet3");

        for (int index = 1; index <= st.getLastRowNum(); index++) {
            FieldConfigInfoDTO fieldConfigInfoDTO = new FieldConfigInfoDTO();

            Row row = st.getRow(index);

            for (int num = 0; num < row.getLastCellNum(); num++) {
                row.getCell(num).setCellType(CellType.STRING);
                String cellValue = row.getCell(num).getStringCellValue();

                switch (num) {
                    case 0:
                        fieldConfigInfoDTO.setField(cellValue);
                        break;
                    case 1:
                        fieldConfigInfoDTO.setValueRange(cellValue);
                        break;
                    case 2:
                        fieldConfigInfoDTO.setValueNum(Integer.parseInt(cellValue));
                        break;
                    default:
                        break;
                }
            }

            // 根据所需要的参数个数更新值域
            updateFieldValueRange(fieldConfigInfoDTO);

            fieldConfigInfoDTOList.add(fieldConfigInfoDTO);
        }

        return fieldConfigInfoDTOList;
    }

    /**
     *
     * @param fieldConfigInfoDTO
     */
    private void updateFieldValueRange(FieldConfigInfoDTO fieldConfigInfoDTO) {
        List<String> valueList = Arrays.asList(StringUtils.splitByWholeSeparator(fieldConfigInfoDTO.getValueRange(), ","));
        int valueNum = fieldConfigInfoDTO.getValueNum();

        if (valueList.size() == valueNum) {
            return;
        }

        if (valueList.size() > valueNum) {
            Collections.shuffle(valueList);
            List<String> randomValues = valueList.subList(0, fieldConfigInfoDTO.getValueNum());

            fieldConfigInfoDTO.setValueRange(randomValues.stream().collect(Collectors.joining(",")));
        }
    }

    /**
     * 动态生成用例数据
     */
    private List<String> generateTestCaseStringInfo(Config config, List<FieldConfigInfoDTO> testCaseFields) {
        List<String> list = new ArrayList<>();
        String strTestCase;

        while (list.size() < config.getTestCaseNum()) {
            // 生成一条测试用例
            strTestCase = generateOneTestCase(testCaseFields);

            if (!list.contains(strTestCase)) {
                list.add(strTestCase);
            }
        }

        return list;
    }

    /**
     *
     */
    private String generateTestCaseHeader(List<FieldConfigInfoDTO> testCaseFields) {
        StringJoiner stringJoiner = new StringJoiner(",");

        for (FieldConfigInfoDTO fieldConfigInfoDTO : testCaseFields) {
            stringJoiner.add(fieldConfigInfoDTO.getField());
        }

        return stringJoiner.toString();
    }

    /**
     * 遍历所有字段，生成一条用例数据
     * @param testCaseFields
     * @return
     */
    private String generateOneTestCase(List<FieldConfigInfoDTO> testCaseFields) {
        StringJoiner stringJoiner = new StringJoiner(",");

        for (FieldConfigInfoDTO fieldConfigInfoDTO : testCaseFields) {
            stringJoiner.add(getFieldRandomValue(fieldConfigInfoDTO));
        }

        return stringJoiner.toString();
    }

    /**
     * 取出某字段的随机值
     * @param fieldConfigInfoDTO
     * @return
     */
    private String getFieldRandomValue(FieldConfigInfoDTO fieldConfigInfoDTO) {
        String[] values = StringUtils.splitByWholeSeparator(fieldConfigInfoDTO.getValueRange(), ",");
        Random random = new Random();
        int index = random.nextInt(values.length);

        return values[index];
    }

    /**
     * 根据用例数据生成用例文件
     */
    private void generateTestCaseCsvFile(Config config, List<String> testCaseInfos, String header) {
        if (CollectionUtils.isEmpty(testCaseInfos)) {
            System.out.println("未生成用例数据，请检查参数后重新再试!");
            return;
        }

        // 生成条数未设定时，则认为为当前条数
        if (0 == config.getTestCaseNum()) {
            config.setTestCaseFileSplit(testCaseInfos.size());
        }

        int startNum = 0;
        int endNum = startNum + config.getTestCaseFileSplit();

        // 更新最后行
        endNum = endNum >= testCaseInfos.size() ? testCaseInfos.size() : endNum;
        StringBuffer sb;

        for (int index = startNum; endNum <= testCaseInfos.size();) {
            String outFilePath = System.getProperty("user.dir") + "\\TestCase_" + System.currentTimeMillis() + ".csv";
            sb = new StringBuffer();

            // 表头
            sb.append(header).append("\n");

            for (int num = startNum; num < endNum; num++) {
                sb.append(testCaseInfos.get(num)).append("\n");
            }

            TxtFileReadUtils.writeFileString(outFilePath, sb.toString());

            if (endNum < testCaseInfos.size() && endNum + config.getTestCaseFileSplit() > testCaseInfos.size()) {
                startNum = endNum;
                endNum = testCaseInfos.size();
            } else {
                startNum = endNum;
                endNum = startNum + config.getTestCaseFileSplit();
            }
        }
    }
}

package com.mnc.smalltool.utils;

import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class TxtFileReadUtils {

    /**
     * read file by file path
     * @param filePath
     * @return
     */
    public static List<String> ReadFile(String filePath) {
        File file = new File(filePath);

        if (file.isFile() && file.exists()) {
            return ReadFile(file);
        }

        return new ArrayList<>();
    }

    /**
     * read file by file
     * @param file
     * @return
     */
    public static List<String> ReadFile(File file) {
        List<String> resultList = new ArrayList<>();

        if (!file.exists()) {
            return resultList;
        }

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String str = null;

            // read the content line by line
            while ((str = br.readLine()) != null) {
                resultList.add(str);
            }

            // close the file reader
            br.close();
        } catch (FileNotFoundException e) {
            log.error("ReadFile has FileNotFoundException : ", e.getMessage());
        } catch (IOException e) {
            log.error("ReadFile has IOException : ", e.getMessage());
        }

        return resultList;
    }

    /**
     * Read path by file
     * @param file
     * @return
     */
    public static List<String> ReadFilePath(File file) {
        File[] files = file.listFiles();

        List<String> fileNameList = new ArrayList<>();

        for (File tempPath : files) {
            fileNameList.add(tempPath.getName());
        }

        return fileNameList;
    }

    /**
     * write file
     * @param filePath
     * @param fileValue
     */
    public static void writeFileString(String filePath, String fileValue) {
        File file = new File(filePath);

        if (!file.exists()) {
            file.delete();
            file = new File(filePath);
        }

        try {
            FileWriter fw = new FileWriter(file);
            fw.write(fileValue);
            fw.flush();
            fw.close();
            Thread.sleep(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

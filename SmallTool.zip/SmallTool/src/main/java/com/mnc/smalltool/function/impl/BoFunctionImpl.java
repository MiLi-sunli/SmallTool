package com.mnc.smalltool.function.impl;

import com.mnc.smalltool.config.Config;
import com.mnc.smalltool.constant.Constant;
import com.mnc.smalltool.function.DTO.FieldInfoDTO;
import com.mnc.smalltool.function.ToolFunction;
import com.mnc.smalltool.utils.CompareUtils;
import com.mnc.smalltool.utils.CopyListUtils;
import com.mnc.smalltool.utils.TxtFileReadUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class BoFunctionImpl implements ToolFunction {

    /**
     * check param
     */
    @Override
    public String checkFunctionParam(Config config) {
        System.out.println("check function 1");
        System.out.println("file path is: " + config.getRootDirectory());
        return null;
    }

    /**
     * execute function
     */
    @Override
    public void executeFunction(Config config) {
        // 用例文件check

        // inbound用例结果对比
        Map<String, Map<Integer, Map<String, List<Object>>>> inboundResultMap = doInboundCaseCompare(config);

        // outbound用例结果对比
        Map<String, Map<Integer, Map<String, List<Object>>>> outboundResultMap = doOutboundCardsCaseCompare(config);

        // 生成结果报告
        generateResultReport(inboundResultMap, outboundResultMap, config);
    }

    /**
     * inbound case compare
     */
    private Map<String, Map<Integer, Map<String, List<Object>>>> doInboundCaseCompare(Config config) {
        // 用例数据: 用例ID，ID对应Inbound数据
        Map<String, Map<Integer, List<FieldInfoDTO>>> inboundCaseValueMap = readInboundValue(config);

        // 用例数据: 用例ID, ID 对应的Input数据
        Map<String, Map<Integer, List<FieldInfoDTO>>> inputCaseValueMap = readInputValue(config, inboundCaseValueMap);

        Map<String, Map<Integer, Map<String, List<Object>>>> compareResultMap = new HashMap<>();

        // 遍历Inbound数据，与Input进行对比测试
        for (Map.Entry<String, Map<Integer, List<FieldInfoDTO>>> caseEntry : inboundCaseValueMap.entrySet()) {
            //
            Map<Integer, Map<String, List<Object>>> caseCompareResultMap = new HashMap<>();

            //
            for (Map.Entry<Integer, List<FieldInfoDTO>> caseLineEntry : caseEntry.getValue().entrySet()) {
                // 对比Inbound与Input对应用例对应行的数据
                Map<String, List<Object>> caseLineResult = CompareUtils.compareFields(caseLineEntry.getValue(), inputCaseValueMap.get(caseEntry.getKey()).get(caseLineEntry.getKey()));

                // 添加某用例某行对比结果
                if (!caseLineResult.isEmpty()) {
                    caseCompareResultMap.put(caseLineEntry.getKey(), caseLineResult);
                }
            }

            // 添加某用例对比结果
            if (!caseCompareResultMap.isEmpty()) {
                compareResultMap.put(caseEntry.getKey(), caseCompareResultMap);
            }
        }

        return compareResultMap;
    }

    /**
     * outbound case compare
     */
    private Map<String, Map<Integer, Map<String, List<Object>>>> doOutboundCardsCaseCompare(Config config) {
        // 用例数据: 用例ID，ID对应OutboundCards数据
        Map<String, Map<Integer, List<FieldInfoDTO>>> outboundCardsCaseValueMap = readOutboundCardsValue(config);
        // 用例数据: 用例ID, ID 对应的Output数据
        Map<String, Map<Integer, List<FieldInfoDTO>>> outputCaseValueMap = readOutputValue(config, outboundCardsCaseValueMap);

        Map<String, Map<Integer, Map<String, List<Object>>>> compareResultMap = new HashMap<>();

        // 遍历outboundCrads数据，与output进行对比测试
        for (Map.Entry<String, Map<Integer, List<FieldInfoDTO>>> caseEntry : outboundCardsCaseValueMap.entrySet()) {
            //
            Map<Integer, Map<String, List<Object>>> caseCompareResultMap = new HashMap<>();

            //
            for (Map.Entry<Integer, List<FieldInfoDTO>> caseLineEntry : caseEntry.getValue().entrySet()) {
                // 对比outbound与output对应用例对应行的数据
                Map<String, List<Object>> caseLineResult = CompareUtils.compareFields(caseLineEntry.getValue(), outputCaseValueMap.get(caseEntry.getKey()).get(caseLineEntry.getKey()));

                // 添加某用例某行对比结果
                if (!caseLineResult.isEmpty()) {
                    caseCompareResultMap.put(caseLineEntry.getKey(), caseLineResult);
                }
            }

            // 添加某用例对比结果
            if (!caseCompareResultMap.isEmpty()) {
                compareResultMap.put(caseEntry.getKey(), caseCompareResultMap);
            }
        }

        return compareResultMap;
    }

    /**
     * generate case result report
     */
    private void generateResultReport(Map<String, Map<Integer, Map<String, List<Object>>>> inboundResultMap, Map<String, Map<Integer, Map<String, List<Object>>>> outboundResultMap, Config config) {
        // TODO
        outPutCaseCompareResult(inboundResultMap, config);

        outPutCaseCompareResult(outboundResultMap, config);
    }


    /**
     * read output file
     */
    private Map<String, Map<Integer, List<FieldInfoDTO>>> readOutputValue(Config config, Map<String, Map<Integer, List<FieldInfoDTO>>> outboundCardsCaseValueMap){

        //构建output字段模板
        List<FieldInfoDTO> moduleDtoList = makeTypeFieldModule(config.getOutput());

        Map<String, Map<Integer, List<FieldInfoDTO>>> resultMap = new HashMap<>();

        // 遍历所有outboundCards文件进行对比
        for (Map.Entry<String, Map<Integer, List<FieldInfoDTO>>> outboundCardsCaseEntry : outboundCardsCaseValueMap.entrySet()) {
            // 用例key
            String caseKey = outboundCardsCaseEntry.getKey();

            // Input文件名
            String outputFileName = "hsbcfd_crds_dmres_2_" + caseKey + "_al_out_sas_ser.csv";

            // 用例内容 行, 内容
            HashMap<Integer, List<FieldInfoDTO>> valueMap = readOutputCaseFile(config.getOutputPath(), outputFileName, moduleDtoList);

            resultMap.put(caseKey, valueMap);
        }

        return resultMap;
    }

    /**
     * readOutputCaseFile
     */
    private HashMap<Integer, List<FieldInfoDTO>> readOutputCaseFile(String outputPath, String outputFileName, List<FieldInfoDTO> moduleDtoList) {
        // 读取用例文件内容
        List<String> valueList = TxtFileReadUtils.ReadFile(outputPath+ "\\" + outputFileName);

        HashMap<Integer, List<FieldInfoDTO>> valueMap = new HashMap<>();

        for (int i = 1; i < valueList.size(); i++) {
            String[] valueSplits = valueList.get(i).split(",");

            // 深拷贝
            List<FieldInfoDTO> row = CopyListUtils.deepCopyList(moduleDtoList);

            for (int index = 0; index < row.size(); index++) {
                row.get(index).setValue(valueSplits[index]);
            }

            valueMap.put(Integer.parseInt(valueSplits[1]), row);
        }

        return valueMap;
    }


    /**
     * read inbound input file
     */
    private Map<String, Map<Integer, List<FieldInfoDTO>>> readInputValue(Config config, Map<String, Map<Integer, List<FieldInfoDTO>>> inboundCaseValueMap) {
        // 构建Input字段模板
        List<FieldInfoDTO> moduleDtoList = makeTypeFieldModule(config.getInput());

        Map<String, Map<Integer, List<FieldInfoDTO>>> resultMap = new HashMap<>();

        // 遍历所有Inbound文件进行对比
        for (Map.Entry<String, Map<Integer, List<FieldInfoDTO>>> inboundCaseEntry : inboundCaseValueMap.entrySet()) {
            // 用例key
            String caseKey = inboundCaseEntry.getKey();

            // Input文件名
            String inputFileName = "hsbcfd_crds_dmreq_2_" + caseKey + "_al_in_sas_ser.csv";

            // 用例内容 行, 内容
            HashMap<Integer, List<FieldInfoDTO>> valueMap = readInputCaseFile(config.getInputPath(), inputFileName, moduleDtoList);

            resultMap.put(caseKey, valueMap);
        }

        return resultMap;
    }

    /**
     * read inbound field module
     */
    private Map<String, Map<Integer, List<FieldInfoDTO>>> readInboundValue(Config config) {
        // 构建Inbound字段模板
        List<FieldInfoDTO> moduleDtoList = makeTypeFieldModule(config.getInbound());

        // 获取测试路径下所有的Inbound文件名
        List<String> inboundFileNameList = TxtFileReadUtils.ReadFilePath(new File(config.getInboundPath()));

        Map<String, Map<Integer, List<FieldInfoDTO>>> resultMap = new HashMap<>();

        // 遍历所有Inbound文件进行对比
        for (String inboundFileName : inboundFileNameList) {
            // 用例key
            String caseKey = inboundFileName.substring(inboundFileName.lastIndexOf("_") + 1, inboundFileName.lastIndexOf("."));

            // 用例内容 行, 内容
            HashMap<Integer, List<FieldInfoDTO>> valueMap = readCaseFile(config.getInboundPath(), inboundFileName, moduleDtoList, 1, -1);

            resultMap.put(caseKey, valueMap);
        }

        return resultMap;
    }


    /**
     * read case file
     */
    private HashMap<Integer, List<FieldInfoDTO>> readCaseFile(String caseFilePath, String FileName, List<FieldInfoDTO> moduleDtoList, int startLine, int deviation) {
        // 读取用例文件内容
        List<String> valueList = TxtFileReadUtils.ReadFile(caseFilePath + "\\" + FileName);

        HashMap<Integer, List<FieldInfoDTO>> valueMap = new HashMap<>();

        for (int i = startLine; i < valueList.size() + deviation; i++) {
            String[] valueSplits = valueList.get(i).split(",");

            // 深拷贝
            List<FieldInfoDTO> row = CopyListUtils.deepCopyList(moduleDtoList);

            for (int index = 0; index < row.size(); index++) {
                row.get(index).setValue(valueSplits[index]);
            }

                valueMap.put(Integer.parseInt(valueSplits[1].substring(1, valueSplits[1].length() - 1)), row);
        }

        return valueMap;
    }

    /**
     * read inbound input file
     */
    private HashMap<Integer, List<FieldInfoDTO>> readInputCaseFile(String caseFilePath, String inboundFileName, List<FieldInfoDTO> moduleDtoList) {
        // 读取Input用例文件内容
        List<String> valueList = TxtFileReadUtils.ReadFile(caseFilePath + "\\" + inboundFileName);

        HashMap<Integer, List<FieldInfoDTO>> valueMap = new HashMap<>();

        for (int i = 1; i < valueList.size(); i++) {
            String[] valueSplits = valueList.get(i).split(",");

            // 深拷贝
            List<FieldInfoDTO> row = CopyListUtils.deepCopyList(moduleDtoList);

            String[] fieldOneSplits = StringUtils.split(valueSplits[0], "|");

            // 组合字段
            for (int index = 0; index < 4; index++) {
                row.get(index).setValue(fieldOneSplits[index]);
            }

            // 非组合字段
            for (int index = 4; index < row.size(); index++) {
                row.get(index).setValue(valueSplits[index - 3]);
            }

            valueMap.put(Integer.parseInt(fieldOneSplits[1].substring(1, fieldOneSplits[1].length() - 1)), row);
        }

        return valueMap;
    }

    /**
     * system print compare result
     */
    private void outPutCaseCompareResult(Map<String, Map<Integer, Map<String, List<Object>>>> resultMap, Config config) {
        StringBuffer sb = new StringBuffer();

        sb.append(Constant.HTMLSTART);
        sb.append("<table width=\"100%\" class=\"twoCalss\">\n");
        sb.append("<tr>\n" +
                "    <td colspan=\"9\" class=\"dataCheckClass\">File comparison results generated</td>\n" +
                "  </tr>\n");
        sb.append("<tr>\n" +
                "    <td class=\"caseClass\" >CaseId</td>\n" +
                "    <td class=\"resultClass\">Result</td>\n" +
                "    <td class=\"lineClass\">Line<br>number</td>\n" +
                "    <td class=\"twoClass\">Field</td>\n" +
                "    <td class=\"fileClass\">File1_Comparison</td>\n" +
                "    <td class=\"fileClass\">File2_Comparison</td>\n" +
                "  </tr>\n");

        for (Map.Entry<String, Map<Integer, Map<String, List<Object>>>> caseEntry : resultMap.entrySet())
        {
            if (caseEntry.getValue().isEmpty()) {
                sb.append("<tr>\n")
                        .append("<td>").append(caseEntry.getKey()).append("</td>\n")
                        .append("<td style='color:forestgreen'>").append("Pass").append("</td>\n")
                        .append("<td colspan='4'> The comparison results are consistent </td>")
                        .append("</tr>\n");
            } else {
                Integer caseRowNum = getSumRowNum(caseEntry.getValue());
                Integer firstLineRowNum = caseEntry.getValue().get(1).size() + 1;

                sb.append("<tr>")
                    //caseId
                    .append("<td rowspan = \"").append(caseRowNum).append("\">").append(caseEntry.getKey()).append("</td>\n")
                    //result
                    .append("<td rowspan = \"").append(caseRowNum).append("\" style=\"color:brown\">").append("Fail").append("</td>\n")
                    .append("<td rowspan = \"").append(firstLineRowNum).append("\">").append("1").append("</td>\n")
                    .append("</tr>");

                // data
                for (Map.Entry<Integer, Map<String, List<Object>>> caseLineEntry : caseEntry.getValue().entrySet()) {
                    // 非第一行，都需要在首个字段前加上此行数据的个数
                    if (1 != caseLineEntry.getKey()) {
                        boolean isFirstLineFlag = true;

                        for (Map.Entry<String, List<Object>> resultEntry : caseLineEntry.getValue().entrySet()) {
                            sb.append("<tr>\n");

                            if (isFirstLineFlag) {
                                sb.append("<td rowspan = \"").append(caseLineEntry.getValue().size()).append("\">").append(caseLineEntry.getKey()).append("</td>\n");
                                isFirstLineFlag = false;
                            }

                            sb.append("<td>").append(resultEntry.getKey()).append("</td>\n")
                                    .append("<td>").append(((FieldInfoDTO) resultEntry.getValue().get(0)).getValue()).append("</td>\n")
                                    .append("<td>").append(((FieldInfoDTO) resultEntry.getValue().get(1)).getValue()).append("</td>\n")
                                    .append("</tr>\n");
                        }
                    } else {
                        for (Map.Entry<String, List<Object>> resultEntry : caseLineEntry.getValue().entrySet()) {
                            sb.append("<tr>\n")
                                    .append("<td>").append(resultEntry.getKey()).append("</td>\n")
                                    .append("<td>").append(((FieldInfoDTO) resultEntry.getValue().get(0)).getValue()).append("</td>\n")
                                    .append("<td>").append(((FieldInfoDTO) resultEntry.getValue().get(1)).getValue()).append("</td>\n")
                                    .append("</tr>\n");
                        }
                    }
                }
            }
        }

        sb.append(Constant.HTMLEND);

        String outFilePath = config.getRootDirectory() + "\\TestReport_" + System.currentTimeMillis() + ".html";
        TxtFileReadUtils.writeFileString(outFilePath, sb.toString());
    }

    private int getSumRowNum(Map<Integer, Map<String, List<Object>>> dataMap) {

        int rowNum = 0;

        for (Map.Entry<Integer, Map<String, List<Object>>> caseLineEntry : dataMap.entrySet()) {
            rowNum += caseLineEntry.getValue().size();
        }

        return rowNum + 1;
    }


    /**
     * read outboundCards
     */
    private  Map<String, Map<Integer, List<FieldInfoDTO>>> readOutboundCardsValue(Config config){
        //构建outbound字段模板
        List<FieldInfoDTO> moduleDtoList = makeTypeFieldModule(config.getOutboundCards());

        // 获取测试路径下所有的outbound文件名
        List<String> outboundCardsFileNameList = TxtFileReadUtils.ReadFilePath(new File(config.getOutboundPath() + "\\cards"));

        Map<String, Map<Integer, List<FieldInfoDTO>>> resultMap = new HashMap<>();

        // 遍历所有outbound文件进行对比
        for (String outboundCardsFileName : outboundCardsFileNameList) {
            // 用例key
            String caseKey = outboundCardsFileName.substring(outboundCardsFileName.lastIndexOf("_") + 1, outboundCardsFileName.lastIndexOf("."));

            // 用例内容 行, 内容
            HashMap<Integer, List<FieldInfoDTO>> valueMap = readOutboundCardsCaseFile(config.getOutboundPath() + "\\cards", outboundCardsFileName, moduleDtoList, 1, -1);

            resultMap.put(caseKey, valueMap);
        }

        return resultMap;
    }

    /**
     * read outboundDwh
     */
    private  Map<String, Map<Integer, List<FieldInfoDTO>>> readOutboundDwhValue(Config config){
        //构建outbound字段模板
        List<FieldInfoDTO> moduleDtoList = makeTypeFieldModule(config.getOutboundDwh());

        // 获取测试路径下所有的outbound文件名
        List<String> outboundDwhFileNameList = TxtFileReadUtils.ReadFilePath(new File(config.getOutboundPath() + "\\dwh"));

        Map<String, Map<Integer, List<FieldInfoDTO>>> resultMap = new HashMap<>();

        // 遍历所有outbound文件进行对比
        for (String outboundDwhFileName : outboundDwhFileNameList) {
            // 用例key
            String caseKey = outboundDwhFileName.substring(outboundDwhFileName.lastIndexOf("_") + 1, outboundDwhFileName.lastIndexOf("."));

            // 用例内容 行, 内容
            HashMap<Integer, List<FieldInfoDTO>> valueMap = readOutboundDwhCaseFile(config.getOutboundPath() + "\\dwh", outboundDwhFileName, moduleDtoList);

            resultMap.put(caseKey, valueMap);
        }

        for (Map.Entry<String, Map<Integer, List<FieldInfoDTO>>> temp : resultMap.entrySet()){
            System.out.println(temp);
        }

        return resultMap;
    }

    /**
     * read outboundHkOutput
     */
    private  Map<String, Map<Integer, List<FieldInfoDTO>>> readOutboundHkOutputValue(Config config){
        //构建outbound字段模板
        List<FieldInfoDTO> moduleDtoList = makeTypeFieldModule(config.getOutboundHkOutput());

        // 获取测试路径下所有的outbound文件名
        List<String> outboundHkOutputFileNameList = TxtFileReadUtils.ReadFilePath(new File(config.getOutboundPath() + "\\hkoutput"));

        Map<String, Map<Integer, List<FieldInfoDTO>>> resultMap = new HashMap<>();

        // 遍历所有outbound文件进行对比

        for (int i = 0; i < 1; i++) {
            // 用例key
            String caseKey = outboundHkOutputFileNameList.get(i).substring(outboundHkOutputFileNameList.get(i).lastIndexOf("_") + 1, outboundHkOutputFileNameList.get(i).lastIndexOf("."));

            // 用例内容 行, 内容
            HashMap<Integer, List<FieldInfoDTO>> valueMap = readOutboundHkOutputCaseFile(config.getOutboundPath() + "\\hkoutput", outboundHkOutputFileNameList.get(i), moduleDtoList);

            resultMap.put(caseKey, valueMap);
        }
        /*for (String outboundHkOutputFileName : outboundHkOutputFileNameList) {
            // 用例key
            String caseKey = outboundHkOutputFileName.substring(outboundHkOutputFileName.lastIndexOf("_") + 1, outboundHkOutputFileName.lastIndexOf("."));

            // 用例内容 行, 内容
            HashMap<Integer, List<FieldInfoDTO>> valueMap = readOutboundHkOutputCaseFile(config.getOutboundPath() + "\\hkoutput", outboundHkOutputFileName, moduleDtoList);

            resultMap.put(caseKey, valueMap);
        }*/

        for (Map.Entry<String, Map<Integer, List<FieldInfoDTO>>> temp : resultMap.entrySet()){
            System.out.println(temp);
        }

        return resultMap;
    }

    /**
     * readOutboundHkOutputCaseFile
     */
    private HashMap<Integer, List<FieldInfoDTO>> readOutboundHkOutputCaseFile(String caseFilePath, String outboundHkOutputFileName, List<FieldInfoDTO> moduleDtoList) {
        // 读取用例文件内容
        List<String> valueList = TxtFileReadUtils.ReadFile(caseFilePath + "\\" + outboundHkOutputFileName);

        HashMap<Integer, List<FieldInfoDTO>> valueMap = new HashMap<>();

        for (int i = 0; i < valueList.size()-1; i++) {
            String[] valueSplits = valueList.get(i).split(",");

            // 深拷贝
            List<FieldInfoDTO> row = CopyListUtils.deepCopyList(moduleDtoList);

            for (int index = 0; index < row.size()-1; index++) {
                row.get(index).setValue(valueSplits[index]);
            }

            valueMap.put(Integer.parseInt(valueSplits[0]), row);
        }

        return valueMap;
    }

    /**
     * read outboundDwh
     */
    private HashMap<Integer, List<FieldInfoDTO>> readOutboundDwhCaseFile(String caseFilePath, String outboundCardsFileName, List<FieldInfoDTO> moduleDtoList) {
        // 读取用例文件内容
        List<String> valueList = TxtFileReadUtils.ReadFile(caseFilePath + "\\" + outboundCardsFileName);

        HashMap<Integer, List<FieldInfoDTO>> valueMap = new HashMap<>();

        for (int i = 1; i < valueList.size(); i++) {
            String[] valueSplits = valueList.get(i).split(",");

            // 深拷贝
            List<FieldInfoDTO> row = CopyListUtils.deepCopyList(moduleDtoList);

            for (int index = 0; index < row.size(); index++) {
                row.get(index).setValue(valueSplits[index]);
            }

            valueMap.put(Integer.parseInt(valueSplits[0].substring(1, valueSplits[0].length() - 1)), row);
        }

        return valueMap;
    }

    /**
     * read outboundCard  file
     */
    private HashMap<Integer, List<FieldInfoDTO>> readOutboundCardsCaseFile(String caseFilePath, String outboundCardsFileName, List<FieldInfoDTO> moduleDtoList, int startLine, int deviation) {

        // 读取Input用例文件内容
        List<String> valueList = TxtFileReadUtils.ReadFile(caseFilePath + "\\" + outboundCardsFileName);

        HashMap<Integer, List<FieldInfoDTO>> valueMap = new HashMap<>();

        for (int i = startLine; i < valueList.size() + deviation; i++) {
            String[] valueSplits = valueList.get(i).split(" ");
            // 深拷贝
            List<FieldInfoDTO> row = CopyListUtils.deepCopyList(moduleDtoList);
                row.get(0).setValue(valueSplits[0].substring(0,3));
                row.get(1).setValue(valueSplits[0].substring(4,23));
                row.get(2).setValue(valueSplits[0].substring(24,25));
                row.get(3).setValue(valueSplits[0].substring(26,34));
                row.get(4).setValue(valueSplits[0].substring(35,42));
                row.get(5).setValue(valueSplits[0].substring(43,44));

            for (int index = 6; index < row.size(); index++) {
                row.get(index).setValue(valueSplits[index - 5]);
            }

            valueMap.put(Integer.parseInt(valueSplits[0].substring(4,23)), row);
        }

        return valueMap;
    }


    /**
     * make field module struct DTO
     */
    private List<FieldInfoDTO> makeTypeFieldModule(String typeConfig) {
        // 获取配置的字段结构
        String[] structs = typeConfig.split(";");
        String[] fieldSplits = null;

        // Inbound字段组成对象
        List<FieldInfoDTO> moduleDtoList = new ArrayList<>();

        // 遍历组装
        for (String struct : structs) {
            fieldSplits = struct.split(",");

            FieldInfoDTO infoDTO = new FieldInfoDTO();
            infoDTO.setField(fieldSplits[0]);
            infoDTO.setType(fieldSplits[1]);

            moduleDtoList.add(infoDTO);
        }

        return moduleDtoList;
    }
}

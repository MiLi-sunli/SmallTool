package com.mnc.smalltool.utils;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

public class ExcelUtils {

    // 日志记录器
    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelUtils.class);

    /**
     * 获取Excel文件
     * @param filePath
     * @return
     */
    public static Workbook getWorkBook(String filePath) {
        File file = new File(filePath);

        if (null == file) {
            return null;
        }

        //创建Workbook工作薄对象，表示整个excel
        Workbook workbook = null;

        try {
            //获取excel文件的io流
            InputStream inputStream = new FileInputStream(file);

            //根据文件后缀名不同(xls和xlsx)获得不同的Workbook实现类对象
            if(file.getName().endsWith("xls")){
                //2003
                workbook = new HSSFWorkbook(inputStream);
            }else if(file.getName().endsWith("xlsx")){
                //2007 及2007以上
                workbook = new XSSFWorkbook(inputStream);
            }
        } catch (IOException e) {
            LOGGER.error(e.getMessage());
        }

        return workbook;
    }

    /**
     * 生成文档
     * @param filePath
     * @param wb
     */
    public static void createExcelFile(String filePath, XSSFWorkbook wb) {
        File targetFile = new File(filePath);

        // 如果目标文档已存在，则先进行删除
        if (targetFile.exists()) {
            targetFile.delete();
        }

        try {
            FileOutputStream outputStream = new FileOutputStream(filePath);
            wb.write(outputStream);

            outputStream.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

package com.mnc.smalltool.constant;

public class Constant {

    public static final String HTMLSTART = "" +
            "<!DOCTYPE html>\n" +
            "  <html lang=\"en\">\n" +
            "  <head>\n" +
            "  <meta charset=\"UTF-8\">\n" +
            "  <title>Compare Results</title>\n" +
            "  </head>\n" +
            "  <style>\n" +
            "table { border-collapse: collapse;}\n" +
            "tr td { border: 0.5px solid darkgrey;text-align-last: center;padding: 5px}\n" +
            ".caseClass {width: 15%}\n" +
            ".resultClass {width: 5%}\n" +
            ".fieldClass {width: 15%}\n" +
            ".lineClass {width: 7%}\n" +
            ".fileClass {width: 40%}\n" +
            ".oneClass {width:100%;background-color: aliceblue}\n" +
            ".twoCalss {background-color: aliceblue}\n" +
            ".dataCheckClass {background-color: cadetblue;}\n" +
            ".fileCheckClass {background-color: cadetblue;}\n" +
            "\n" +
            "  </style>\n" +
            "  <body>\n";


    public static final String HTMLEND = "" +
            "</table>\n"+
            "</body>\n" +
            "</html>";
}

package com.mnc.smalltool.config;

import lombok.Data;

/**
 * yaml file config info
 */
@Data
public class Config {
    //
    private String input;

    //
    private String inputPath;

    //
    private String inbound;

    //
    private String inboundPath;

    //
    private String output;

    //
    private String outboundCards;

    //
    private String outboundDwh;

    //
    private String outboundHkOutput;

    //
    private String rootDirectory;

    //
    private String outputPath;

    //
    private String outboundPath;

    // 用例总条数
    private int testCaseNum = 0;

    // 用例文件条数分割
    private int testCaseFileSplit = 0;

    //
    private String testCaseConfigFileName;

    private String htmlStart;

    private String htmlEnd;
}

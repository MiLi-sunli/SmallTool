package com.mnc.smalltool.function.DTO;

import lombok.Data;

import java.io.Serializable;

@Data
public class FieldInfoDTO implements Serializable {

    private static final long serialVersionUID = -7001256505696147465L;

    // 字段名
    private String field;

    // 字段值
    private String value;

    // 字段类型
    private String type;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "FieldInfoDTO{" +
                "field='" + field + '\'' +
                ", value='" + value + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}

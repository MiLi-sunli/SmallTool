package com.mnc.smalltool.function;

import com.mnc.smalltool.config.Config;

public interface ToolFunction {
    /**
     * check the param
     * @return
     */
    String checkFunctionParam(Config config);

    /**
     * execute Function
     */
    void executeFunction(Config config);
}

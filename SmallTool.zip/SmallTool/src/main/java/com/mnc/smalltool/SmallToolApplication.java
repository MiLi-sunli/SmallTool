package com.mnc.smalltool;

import com.mnc.smalltool.menu.ToolMenu;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmallToolApplication {

    public static void main(String[] args) {
        args = new String[1];
        args[0] = "1";

        SpringApplication application = new SpringApplication(SmallToolApplication.class);
        application.setBannerMode(Banner.Mode.OFF);
        application.run(args);

        ToolMenu toolMenu = new ToolMenu();
        toolMenu.executeToolFunction(args);
    }
}
